﻿namespace OpenCvSharp;

/// <summary>
/// cv::ORB score flags
/// </summary>
// ReSharper disable once InconsistentNaming
public enum ORBScoreType
{
    /// <summary>
    /// 
    /// </summary>
    Fast = 1,

    /// <summary>
    /// 
    /// </summary>
    Harris = 0,
}
