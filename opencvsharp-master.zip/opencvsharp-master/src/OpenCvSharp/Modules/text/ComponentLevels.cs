﻿namespace OpenCvSharp.Text;

/// <summary>
/// 
/// </summary>
public enum ComponentLevels
{
    /// <summary>
    /// 
    /// </summary>
    Word,

    /// <summary>
    /// 
    /// </summary>
    TextLine
}
