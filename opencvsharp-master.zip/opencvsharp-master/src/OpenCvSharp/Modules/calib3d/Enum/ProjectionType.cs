﻿namespace OpenCvSharp;

/// <summary>
/// cv::initWideAngleProjMap flags
/// </summary>
public enum ProjectionType
{
    /// <summary>
    /// 
    /// </summary>
    SphericalOrtho = 0,

    /// <summary>
    /// 
    /// </summary>
    SphericalEqRect = 1,
}
