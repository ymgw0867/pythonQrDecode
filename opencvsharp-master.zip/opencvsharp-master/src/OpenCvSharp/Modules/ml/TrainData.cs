﻿using System;

namespace OpenCvSharp.ML;

/// <summary>
/// 
/// </summary>
public class TrainData
{
    /// <summary>
    /// 
    /// </summary>
    public TrainData()
    {
        throw new NotImplementedException();
    }
}
